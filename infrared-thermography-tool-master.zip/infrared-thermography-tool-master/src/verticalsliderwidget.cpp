#include "verticalsliderwidget.h"

#include <QBrush>
#include <QColor>
#include <QGraphicsScene>
#include <QGraphicsProxyWidget>
#include <QLinearGradient>
#include <QPainter>
#include <QPen>
#include <QSlider>
#include <QStyle>
#include <QStyleOptionSlider>



#define SLIDER_HEIGHT 600
#define SLIDER_WIDTH 100
#define COLOR_WEIGHT 200


VerticalSliderWidget::VerticalSliderWidget(QWidget *parent)
    : QGraphicsView(parent)
{

    QGraphicsScene *scene = new QGraphicsScene(this);

    setScene(scene);
    setFixedWidth(130);
    setCacheMode(CacheBackground);
    setFrameStyle(QFrame::NoFrame);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setRenderHint(QPainter::Antialiasing);

    m_scale = new Scale;
    scene->addItem(m_scale);
    m_scale->setPos(0, 0);

    m_slider = new Slider;
    QGraphicsProxyWidget * widget = scene->addWidget(m_slider);
    widget->setPos(60, 0);
}

VerticalSliderWidget::~VerticalSliderWidget()
{

}

Scale::Scale(QGraphicsItem *parent)
    : QGraphicsObject(parent),
      m_width(8),
      m_height(680),
      m_scaleStart(0),
      m_scaleEnd(65000),
      m_intervalCount(13),
      m_locale(QLocale::English)
{
}


void Scale::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->setPen(Qt::NoPen);
    QLinearGradient gradient(0, 0, 0, m_height);
    gradient.setStart(0, 0);
    gradient.setColorAt(0, Qt::red);
    gradient.setColorAt(0.5, Qt::yellow);
    gradient.setColorAt(1, Qt::blue);
    painter->setBrush(QBrush(gradient));
    painter->drawRect(0, 0, m_width, m_height);

    painter->setPen(QPen(Qt::black, 0.5));
    painter->drawLine(QPointF(m_width + 5, 0), QPointF(m_width + 5, m_height));

    float largeScale = (m_scaleEnd - m_scaleStart) / (m_intervalCount);
    largeScale = (largeScale <= 100) ? 100 :
                 (largeScale <= 400) ? 200 :
                 (largeScale <= 1000) ? 500 :
                 (largeScale <= 2000) ? 1000 :
                 (largeScale <= 4000) ? 2000 : 5000;
    float smallScale = largeScale / 5;
    float smallScaleInterval = m_height / ((m_scaleEnd - m_scaleStart) / smallScale);

    int currentPoint = (static_cast<int>(m_scaleStart) / static_cast<int>(smallScale)) * smallScale;
    float currentInterval = 0;
    while (currentPoint < m_scaleEnd)
    {
        if (currentPoint % static_cast<int>(largeScale) == 0)
        {
            painter->drawLine(QPointF(m_width + 6, m_height - currentInterval),
                              QPointF(m_width + 14, m_height - currentInterval));
            painter->drawText(QPointF(m_width + 18, m_height - currentInterval + 4), m_locale.toString(currentPoint));
        }
        else if (currentPoint % static_cast<int>(smallScale) == 0)
        {
            painter->drawLine(QPointF(m_width + 6, m_height - currentInterval),
                              QPointF(m_width + 10, m_height - currentInterval));
        }

        currentPoint += smallScale;
        currentInterval += smallScaleInterval;
    }
}

QRectF Scale::boundingRect() const
{
    return QRectF(0, 0, m_width, m_height).adjusted(40, 40, 40, 40);
}

Slider::Slider(QWidget *parent)
    : QSlider(parent)
{
}

void Slider::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    painter->
}

































