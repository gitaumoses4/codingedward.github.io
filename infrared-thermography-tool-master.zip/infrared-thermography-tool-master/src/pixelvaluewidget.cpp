// mine
#include "pixelvaluewidget.h"

// qt
#include <QFont>

PixelValueWidget::PixelValueWidget(QWidget *parent)
    : QLabel(parent),
      m_p(0),
      m_x(0),
      m_y(0)
{
    setTextFormat(Qt::RichText);
    setFont(QFont("sans serif", 12, QFont::Monospace));
    updateText();
}

void PixelValueWidget::setMouseAt(int x, int y)
{
    m_x = x;
    m_y = y;
    updateText();
}


void PixelValueWidget::setPixel(int p)
{
    m_p = p;
    updateText();
}

void PixelValueWidget::updateText()
{
    // updates the text of the widget
    setText(QString("<div style='color: rgb(0, 128, 128);'>P: %1; X = %2; Y = %3</div>")
             .arg(m_p)
             .arg(m_x)
             .arg(m_y));
}
