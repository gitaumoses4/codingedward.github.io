// mine
#include "verticalscale.h"

// qwt
#include <qwt_color_map.h>
#include <qwt_scale_div.h>

// qt
#include <QBrush>
#include <QDebug>
#include <QPainter>

// opencv
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc.hpp>

VerticalScale::VerticalScale(QWidget *parent)
    : QwtThermo(parent),
      m_maxMajorScale(15),
      m_maxMinorScale(5)
{
    m_colormap = -1;
    setOrientation(Qt::Vertical);
    setPipeWidth(8);
    setBorderWidth(0);
    setScalePosition(QwtThermo::LeadingScale);

    setScale(0, 65535);

    setScaleMaxMajor(m_maxMajorScale);
    setScaleMaxMinor(m_maxMinorScale);
}

void VerticalScale::setScaleColormap(int colormap)
{
    m_colormap = colormap;
    update();
}

void VerticalScale::drawLiquid(QPainter *painter, const QRect &rect) const
{
    // this will draw the liquid of the scale by first creating an
    // image with values within the range of this scale and then
    // applying a colormap on it

    // the image is going to be an 8 bit image, therefore we divide the bounds
    double low = lowerBound() / 255.0;
    double range = (upperBound() - lowerBound())  / 255.0;

    cv::Mat liquidMat(rect.height(), rect.width(), CV_8U);

    int rows = liquidMat.rows;
    for (int i = 0; i < rows; ++i)
    {
        liquidMat.row(i).setTo(low + (range * (rows - i - 1) / (double)rows));
    }


    if (m_colormap != -1)
    {
        cv::applyColorMap(liquidMat, liquidMat, m_colormap);
        cv::cvtColor(liquidMat, liquidMat, cv::COLOR_BGR2RGB);
    }
    else
    {
        cv::cvtColor(liquidMat, liquidMat, cv::COLOR_GRAY2RGB);
    }
    QImage image = QImage((uchar*)liquidMat.data,
                          liquidMat.cols, liquidMat.rows,
                          liquidMat.step, QImage::Format_RGB888);

    painter->setPen(Qt::NoPen);
    painter->drawPixmap(rect, QPixmap::fromImage(image));
}

void VerticalScale::customSetRange(const int low, const int high)
{
    // checks to see if the scale should change or not
    if (((high - low) > (m_maxMajorScale * 100)) || low < lowerBound() || high > upperBound())
    {
        setScale(low, high);
    }
}
