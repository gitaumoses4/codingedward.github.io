#ifndef SELECTIONAREA_H
#define SELECTIONAREA_H

#include <QGraphicsItem>

class SelectionArea : public QGraphicsItem
{
public:
    SelectionArea(QGraphicsItem *parent = 0);

    void setStartPoint(QPointF startPoint);

    void setEndPoint(QPointF endPoint);

protected:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *) Q_DECL_OVERRIDE;
    QRectF boundingRect() const;

private:
    QPointF m_endPoint;
    QPointF m_startPoint;
};

#endif // SELECTIONAREA_H
