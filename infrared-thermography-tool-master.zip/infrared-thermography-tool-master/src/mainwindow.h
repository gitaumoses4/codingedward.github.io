#ifndef MAINWINDOW_H
#define MAINWINDOW_H

// qt
#include <QList>
#include <QMainWindow>

class QAction;
class QToolBar;

// mine
class CentralWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);

private slots:
    /**
     * @brief loadImage loads the image into display
     */
    void loadImage();

    /**
     * @brief saveImage saves the image currently in display
     */
    void saveImage();

private:
    /**
     * @brief m_openAct an action for opening a new image
     */
    QAction *m_openAct;

    /**
     * @brief m_saveAct an action for saving the image in display
     */
    QAction *m_saveAct;

    /**
     * @brief m_zoomInAct an action for zooming into image displayed
     */
    QAction *m_zoomInAct;

    /**
     * @brief m_zoomOutAct an action for zooming out of the image displayed
     */
    QAction *m_zoomOutAct;

    /**
     * @brief m_resetZoomAct an action for resetting the zoom of the image displayed
     */
    QAction *m_resetZoomAct;

    /**
     * @brief m_clearAct an action for clearing the images already loaded
     */
    QAction *m_clearAct;

    /**
     * @brief m_toolbar the toolbar of the main window
     */
    QToolBar *m_toolbar;

    /**
     * @brief m_centralWidget the central widget holding all other widgets
     */
    CentralWidget *m_centralWidget;

    /**
     * @brief m_imagePath a list of already opened images
     */
    QList<QString> m_imagePath;
};

#endif // MAINWINDOW_H
