// mine
#include "pixmapitem.h"
#include "imagepanelwidget.h"

// qt
#include <QGraphicsSceneMouseEvent>
#include <QKeyEvent>
#include <QGraphicsView>
#include <QDebug>

PixmapItem::PixmapItem(QGraphicsItem *parent)
    : QObject(),
      QGraphicsPixmapItem(parent)
{
    // set flags.
    setFlag(ItemIsMovable);
    setFlag(ItemSendsGeometryChanges);
}

void PixmapItem::checkBoundaries()
{
    // get view
    ImagePanelWidget *view =
            qobject_cast<ImagePanelWidget *>(scene()->views().last());
    // bounding rects relatvie to the scene.
    QRect itemRect = view->mapFromScene(mapToScene(boundingRect())).boundingRect();
    QRect viewRect =
            mapFromScene(
                view->mapToScene(
                    view->viewport()->geometry()
                )
            ).boundingRect().toAlignedRect();

    // scale coordinates
    itemRect.setX(itemRect.x() / view->getScale());
    itemRect.setY(itemRect.y() / view->getScale());
    itemRect.setRight(itemRect.right() / view->getScale());
    itemRect.setBottom(itemRect.bottom() / view->getScale());

    QPointF point = itemRect.topLeft(); // final point
    if (viewRect.width() < itemRect.width())
    {
        // left
        if (viewRect.left() < 0)
        {
            point.setX(0);
            setPos(view->mapToScene(point.toPoint() * view->getScale()));
        }

        // right
        if (itemRect.right() < viewRect.width())
        {
            point.setX(point.x() + viewRect.width() - itemRect.right());
            setPos(view->mapToScene(point.toPoint() * view->getScale()).toPoint());
        }
    }


    if (viewRect.height() < itemRect.height())
    {
        // top
        if (viewRect.top() < 0)
        {
            point.setY(0);
            setPos(view->mapToScene(point.toPoint() * view->getScale()));
        }

        // bottom
        if (itemRect.bottom() < viewRect.height())
        {
            point.setY(point.y() + viewRect.height() - itemRect.bottom());
            setPos(view->mapToScene(point.toPoint() * view->getScale()).toPoint());
        }
    }
}

void PixmapItem::keyReleaseEvent(QKeyEvent *event)
{
    if (! scene()) return;

    if (event->key() == Qt::Key_Escape)
        emit selectionAreaChanged(QPointF(0, 0), QPointF(0, 0));

    QGraphicsPixmapItem::keyReleaseEvent(event);
}

void PixmapItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if (! scene()) return;

    if (event->modifiers() == Qt::ControlModifier)
    {
        m_selectionStart = event->scenePos();
    }

//  emit selectionAreaChanged(QPointF(), QPointF());

    QGraphicsPixmapItem::mousePressEvent(event);
}


void PixmapItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    if (! scene()) return;

    if (event->modifiers() == Qt::ControlModifier)
    {
        emit selectionAreaChanged(m_selectionStart, event->scenePos());
    }
    else if (m_selectionStart == QPointF())
    {
        QGraphicsPixmapItem::mouseMoveEvent(event);
        checkBoundaries();
    }
}

void PixmapItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    if (! scene()) return;

    if (event->modifiers() == Qt::ControlModifier)
    {
        //emit selectionAreaChanged(QPointF(), QPointF());
    }
    m_selectionStart = QPointF();
    QGraphicsPixmapItem::mouseReleaseEvent(event);
}

QVariant PixmapItem::itemChange(GraphicsItemChange change, const QVariant &value)
{
    emit centerItem();
    return QGraphicsPixmapItem::itemChange(change, value);

}
