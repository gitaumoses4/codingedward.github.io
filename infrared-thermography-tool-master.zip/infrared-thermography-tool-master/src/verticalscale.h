#ifndef VERTICALSCALE_H
#define VERTICALSCALE_H

// opencv
#include <qwt_thermo.h>

/**
 * @brief The VerticalScale class holds the scale ticks and fluid displayed
 */
class VerticalScale : public QwtThermo
{
    Q_OBJECT
public:
    /**
     * @brief VerticalScale the constructor
     * @param parent this widget's parent
     */
    VerticalScale(QWidget *parent);

signals:
    /**
     * @brief scaleChanged notifies that the scale has changed
     * @param low lower value of the scale range
     * @param high upper value of the scale range
     */
    void scaleChanged(int low, int high);

public slots:
    /**
     * @brief setScaleColormap sets the colormap of the scale liquid
     * @param colormap the colormap enum value, -1 if no colormap is set
     */
    void setScaleColormap(int colormap);

    /**
     * @brief customSetRange set this widgets scale range
     * @param low lower value of the range
     * @param high upper value of the range
     * @return true if the scale changed, false otherwise
     */
    void customSetRange(const int low, const int high);

protected:
    /**
     * @brief drawLiquid implemented for drawing the colormap for the scale
     * @param painter this widget's painter object
     * @param rect the rectangle where to draw the colormap
     */
    void drawLiquid(QPainter *painter, const QRect &rect) const Q_DECL_OVERRIDE;

private:
    /**
     * @brief m_maxMajorScale major scale maximum intervals count
     */
    int m_maxMajorScale;

    /**
     * @brief m_maxMinorScale minor scale maximum intervals count
     */
    int m_maxMinorScale;

    /**
     * @brief m_colormap current colormap
     */
    int m_colormap;
};

#endif // VERTICALSCALE_H
