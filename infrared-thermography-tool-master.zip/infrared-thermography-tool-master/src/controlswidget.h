#ifndef COLORMAPWIDGET_H
#define COLORMAPWIDGET_H

// qt
#include <QGroupBox>
#include <QMap>

class QComboBox;
class QLabel;
class QPushButton;
class QxtSpanSlider;

// opencv
#include <opencv2/imgproc/imgproc.hpp>

/**
 * @brief The ControlsWidget class holds the image histogram and other controls
 */
class ControlsWidget : public QGroupBox
{
    Q_OBJECT
public:
    /**
     * @brief ControlsWidget the constructor
     * @param parent this widget's parent
     */
    ControlsWidget(QWidget *parent = 0);

signals:
    /**
     * @brief resetZoomLevel notifies that current zoom level has changed
     */
    void resetZoomLevel();

    /**
     * @brief resetNormalizeImage notifies normalize range reset has been requested
     */
    void resetNormalizeImage();

    /**
     * @brief colormapChanged notifies widgets that the colormap has been changed
     */
    void colormapChanged(int);

    /**
     * @brief scaleChanged notifies other widgets that the normalize range has changed
     * @param low the lower value of the range
     * @param high the upper value of the range
     * @param sliderReleased indicates if the slider has been released to provide
     * realtime experience if not, and update other widgets if released.
     */
    void scaleChanged(int low, int high, bool sliderReleased);

public slots:
    /**
     * @brief clear resets everything in the widget.
     */
    void clear();

    /**
     * @brief updateHistogram this draws the image histogram
     *
     * The function draws the image histogram by taking the image matrix and
     * the range of the pixel values.
     *
     * @param sourceMat the image for which the histogram is drawn
     */
    void updateHistogram(const cv::Mat &sourceMat);

    /**
     * @brief changeScale changes the widget's scale based on the values of other scales
     * for synchronization
     * @param low the lower value of the scale range
     * @param high the upper value of the scale range.
     */
    void changeScale(int low, int high);


protected:
    /**
     * @brief paintEvent paint event for this widget overriden to support stylesheets
     * @param event
     */
    void paintEvent(QPaintEvent *event);

private slots:
    /**
     * @brief setColormap sets current colormap and notifies other widgets
     */
    void setColormap();

    /**
     * @brief syncScaleDragged syncs image displayed with current scale value
     */
    void syncScaleDragged();

    /**
     * @brief syncScaleReleased syncs image displayed with current scale value and
     * updates other widgets.
     */
    void syncScaleReleased();

private:
    /**
     * @brief m_histLbl the label for the histogram
     */
    QLabel      *m_histLbl;

    /**
     * @brief m_colormapLbl the colormap image label
     */
    QLabel      *m_colormapLbl;

    /**
     * @brief m_colormapCbo the combobox for selecting colormaps
     */
    QComboBox   *m_colormapCbo;

    /**
     * @brief m_resetRangeBtn resets the range for image normalization
     */
    QPushButton *m_resetRangeBtn;

    /**
     * @brief m_resetZoomBtn resets current display image zoom level
     */
    QPushButton *m_resetZoomBtn;

    /**
     * @brief m_slider the scale slider for the range of normalization
     */
    QxtSpanSlider *m_slider;

    /**
     * @brief m_colormaps a map of colormaps against their names used with
     * the combo box.
     */
    QMap<QString, int> m_colormaps;
};

#endif // COLORMAPWIDGET_H
