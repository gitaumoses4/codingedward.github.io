// mine
#include "controlswidget.h"
#include "qxtspanslider.h"


// qt
#include <QPushButton>
#include <QComboBox>
#include <QDebug>
#include <QLabel>
#include <QVBoxLayout>
#include <QPainter>
#include <QSizePolicy>

// opencv
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

// stl
#include <vector>

#define HIST_WIDTH 170
#define HIST_HEIGHT 80
#define COLORMAP_HEIGHT 50
#define COLORMAP_WIDTH 170


ControlsWidget::ControlsWidget(QWidget *parent)
    : QGroupBox(tr("Controls"), parent)
{
    // styling
    setStyleSheet(" ControlsWidget{ background-color: rgb(240, 240, 240); }");

    // we setup a key value map for colormaps
    m_colormaps["-- No Colormap --"] = -1;
    m_colormaps["Autumn"]   = cv::COLORMAP_AUTUMN ;
    m_colormaps["Bone"]     = cv::COLORMAP_BONE;
    m_colormaps["Jet"]      = cv::COLORMAP_JET;
    m_colormaps["Winter"]   = cv::COLORMAP_WINTER;
    m_colormaps["Rainbow"]  = cv::COLORMAP_RAINBOW;
    m_colormaps["Ocean"]    = cv::COLORMAP_OCEAN;
    m_colormaps["Summer"]   = cv::COLORMAP_SUMMER;
    m_colormaps["Spring"]   = cv::COLORMAP_SPRING;
    m_colormaps["Cool"]     = cv::COLORMAP_COOL;
    m_colormaps["HSV"]      = cv::COLORMAP_HSV;
    m_colormaps["Pink"]     = cv::COLORMAP_PINK;
    m_colormaps["Hot"]      = cv::COLORMAP_HOT;
    m_colormaps["Parula"]   = cv::COLORMAP_PARULA;

    // initialize items and set layout
    QVBoxLayout *layout = new QVBoxLayout(this);

    m_colormapCbo = new QComboBox(this);
    m_colormapCbo->addItems(m_colormaps.keys());

    m_histLbl = new QLabel(this);
    m_histLbl->setCursor(Qt::CrossCursor);
    m_histLbl->setFixedSize(HIST_WIDTH, HIST_HEIGHT);
    QHBoxLayout *histLayout = new QHBoxLayout;
    histLayout->addWidget(m_histLbl);

    m_colormapLbl = new QLabel(this);
    m_colormapLbl->setFixedHeight(COLORMAP_HEIGHT);
    m_colormapLbl->setFrameStyle(QFrame::Panel);

    QGroupBox *resetBox = new QGroupBox(tr("Reset"),this);
    QVBoxLayout *resetBoxLayout = new QVBoxLayout(resetBox);
    m_resetZoomBtn = new QPushButton(tr("Zoom"), this);
    m_resetRangeBtn = new QPushButton(tr("Range"), this);
    resetBoxLayout->addWidget(m_resetZoomBtn);
    resetBoxLayout->addSpacing(5);
    resetBoxLayout->addWidget(m_resetRangeBtn);

    m_slider = new QxtSpanSlider(Qt::Horizontal,this);
    m_slider->setTickPosition(QSlider::TicksBothSides);
    m_slider->setTickInterval(32767); // -------------- half of 65535
    m_slider->setStyleSheet(" QxtSpanSlider::handle:horizontal { image: url(:/resources/needle.png); } ");
    m_slider->setRange(0, 65535);
    m_slider->setSpan(0, 65535);


    layout->addWidget(m_colormapCbo);
    layout->addSpacing(10);
    layout->addLayout(histLayout);
    layout->addWidget(m_colormapLbl);
    layout->addWidget(m_slider);
    layout->addSpacing(30);
    layout->addWidget(resetBox);


    // make connections...
    connect(m_resetZoomBtn, SIGNAL(clicked(bool)), this, SIGNAL(resetZoomLevel()));
    connect(m_resetRangeBtn, SIGNAL(clicked(bool)), this, SIGNAL(resetNormalizeImage()));
    connect(m_colormapCbo, SIGNAL(currentIndexChanged(int)), SLOT(setColormap()));
    connect(m_slider, SIGNAL(spanChanged(int,int)), this, SLOT(syncScaleDragged()));
    connect(m_slider, SIGNAL(sliderReleased()), this, SLOT(syncScaleReleased()));

    setColormap();
}


void ControlsWidget::clear()
{
    // reset everything
    m_histLbl->setPixmap(QPixmap());
    m_slider->setSpan(0, 65535);
    m_colormapCbo->setCurrentIndex(0);
}

void ControlsWidget::updateHistogram(const cv::Mat &sourceMat)
{

    int histSize = 256;
    float range[] = {0, (float)histSize};
    const float *histRange = {range};

    bool uniform = true;
    bool accumulate = false;

    cv::Mat destMat;

    int channels[] = {0, 1, 2, 3};

    cv::calcHist(&sourceMat, 1, channels, cv::Mat(), destMat, 1, &histSize, &histRange, uniform, accumulate);

    // draw the histograms for B, G, R and A
    int histWidth = 256;
    int histHeight = 500;
    int binWidth = cvRound((double) histWidth / histSize);

    cv::Mat histImage(histHeight, histWidth, CV_8UC3, cv::Scalar(240, 240, 240));

    // normalize the histogram
    cv::normalize(destMat, destMat, 0, histImage.rows, cv::NORM_MINMAX, -1, cv::Mat());

    // now draw the histogram
    for (int i = 1; i < histSize; ++i)
    {

        cv::line(histImage, cv::Point( binWidth * (i - 1), histHeight - cvRound(destMat.at<float>(i - 1)) ),
                            cv::Point( binWidth * (i),     histHeight - cvRound(destMat.at<float>(i)) ),
                            cv::Scalar(0, 128, 129), 1, 8, 0 );
        cv::line(histImage, cv::Point( binWidth * (i - 1), histHeight ),
                            cv::Point( binWidth * (i),     histHeight - cvRound(destMat.at<float>(i)) ),
                            cv::Scalar(0, 128, 129), 8, 8, 0 );
    }

    // get image data and set it.
    QImage image = QImage((uchar*)histImage.data,
                          histImage.cols, histImage.rows,
                          histImage.step, QImage::Format_RGB888);
    m_histLbl->setPixmap(QPixmap::fromImage(image).scaled(HIST_WIDTH - 2, HIST_HEIGHT));
}


void ControlsWidget::changeScale(int low, int high)
{
    // set slider scale
    if (low != m_slider->lowerValue() || high != m_slider->upperValue())
        m_slider->setSpan(low, high);
}

void ControlsWidget::paintEvent(QPaintEvent *event)
{
    // to support styling
    QStyleOption option;
    option.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &p, this);
    QGroupBox::paintEvent(event);
}

void ControlsWidget::setColormap()
{
    // this will change the colormap displayed by the
    // rectangular widget, we need to draw it and then
    // change it to a QPixmap for display
    cv::Mat colormapMat(COLORMAP_HEIGHT, 255, CV_8U);

    for (int i = 0; i < colormapMat.cols; ++i)
        colormapMat.col(i).setTo(i);


    int colormap = m_colormaps[m_colormapCbo->currentText()];

    if (colormap != -1)
    {
        cv::applyColorMap(colormapMat, colormapMat, colormap);
        cv::cvtColor(colormapMat, colormapMat, cv::COLOR_BGR2RGB);
    }
    else
    {
        cv::cvtColor(colormapMat, colormapMat, cv::COLOR_GRAY2BGR);
    }

    QImage image = QImage((uchar*)colormapMat.data,
                          colormapMat.cols, colormapMat.rows,
                          colormapMat.step, QImage::Format_RGB888);
    m_colormapLbl->setPixmap(QPixmap::fromImage(image).scaled(COLORMAP_WIDTH, COLORMAP_HEIGHT));


    emit colormapChanged(colormap);
}


void ControlsWidget::syncScaleDragged()
{
    emit scaleChanged(m_slider->lowerValue(), m_slider->upperValue(), false);
}

void ControlsWidget::syncScaleReleased()
{
    emit scaleChanged(m_slider->lowerValue(), m_slider->upperValue(), true);
}
