#ifndef SCALEWIDGET_H
#define SCALEWIDGET_H

// qt
#include <QWidget>

// mine
class VerticalScale;
class VerticalSlider;

/**
 * @brief The VerticalScaleWidget class holds the vertical slider and scale widget
 */
class VerticalScaleWidget : public QWidget
{
    Q_OBJECT
public:
    /**
     * @brief VerticalScaleWidget the constructor
     * @param parent this widget's parent
     */
    VerticalScaleWidget(QWidget *parent = 0);

public slots:
    /**
     * @brief changeScale updates both the slider's and scale range
     * @param low the lower value of the range
     * @param high the upper value of the range
     */
    void changeScale(int low, int high);

    /**
     * @brief changeColormap sets the scale's thermo liquid colormap
     * @param colormap the colormap
     */
    void changeColormap(int colormap);

signals:
    /**
     * @brief scaleChanged notifies other widgets of the slider range values
     * changing
     * @param low the lower value of the range
     * @param high the upper value of the range
     * @param released indicates if the slider is released or not for performance and
     * image quality tradeoff
     */
    void scaleChanged(int low, int high, bool released);

protected:
    /**
     * @brief paintEvent the paint event for this widget to support styling
     */
    void paintEvent(QPaintEvent *);

private slots:
    /**
     * @brief syncScaleReleased syncs scales range when the slider is released
     */
    void syncScaleReleased();

    /**
     * @brief syncScaleDragged syncs scales range when the slider is dragged
     */
    void syncScaleDragged();

private:
    /**
     * @brief m_scale the scale widget
     */
    VerticalScale   *m_scale;

    /**
     * @brief m_slider the slider widget
     */
    VerticalSlider  *m_slider;

};

#endif // SCALEWIDGET_H
