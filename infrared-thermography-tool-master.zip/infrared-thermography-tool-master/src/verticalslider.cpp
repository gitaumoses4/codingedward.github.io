#include "verticalslider.h"

VerticalSlider::VerticalSlider(QWidget *parent)
    : QxtSpanSlider(parent)
{
    setStyleSheet(" QSlider::handle { background-color: rgb(56, 145, 200); border-radius: 5px;  } ");
    setRange(0, 65535);
    setLowerValue(0);
    setUpperValue(65535);
    setOrientation(Qt::Vertical);
}

