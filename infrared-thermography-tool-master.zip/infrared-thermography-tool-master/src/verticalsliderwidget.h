#ifndef VERTICALSLIDEWIDGET_H
#define VERTICALSLIDEWIDGET_H

#include <QLocale>
#include <QGraphicsObject>
#include <QGraphicsView>
#include <QSlider>


class Scale : public QGraphicsObject
{
    Q_OBJECT
public:
    Scale(QGraphicsItem *parent = 0);

protected:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *) Q_DECL_OVERRIDE;
    QRectF boundingRect() const Q_DECL_OVERRIDE;

private:
    float m_width;
    float m_height;
    float m_scaleStart;
    float m_scaleEnd;
    float m_intervalCount;
    QLocale m_locale;
};


class Slider : public QGraphicsObject
{
    Q_OBJECT
public:
    Slider(QWidget *parent = 0);

protected:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *) Q_DECL_OVERRIDE;
    QRectF boundingRect() const Q_DECL_OVERRIDE;

};




class VerticalSliderWidget : public QGraphicsView
{
    Q_OBJECT
public:
    VerticalSliderWidget(QWidget *parent = 0);
    ~VerticalSliderWidget();

private:
    QSlider *m_slider;
    Scale   *m_scale;
};

#endif // VERTICALSLIDEWIDGET_H
