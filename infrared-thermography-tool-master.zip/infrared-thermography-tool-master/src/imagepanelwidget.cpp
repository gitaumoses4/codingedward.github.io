// mine
#include "imagepanelwidget.h"
#include "pixmapitem.h"
#include "selectionarea.h"

// stl
#include <math.h>

// qt
#include <QKeyEvent>
#include <QDebug>
#include <QMainWindow>
#include <QGraphicsPixmapItem>

// constants
#define PANEL_HEIGHT 550
#define PANEL_WIDTH  900

ImagePanelWidget::ImagePanelWidget(QWidget *parent)
    : QGraphicsView(parent)
{
    m_scale = 1;

    // setup the scene
    QGraphicsScene *scene = new QGraphicsScene(this);
    scene->setItemIndexMethod(QGraphicsScene::NoIndex);
    setScene(scene);
    setSceneRect(0, 0, frameSize().width(), frameSize().height());

    // some flags
    setCacheMode(CacheBackground);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
//  setMaximumSize(PANEL_WIDTH, PANEL_HEIGHT);
    setRenderHint(QPainter::Antialiasing);
    setTransformationAnchor(AnchorUnderMouse);
    setWindowTitle(tr("Image Color Maps"));

    // initialize the pixmap item
    m_pixmapItem = new PixmapItem;
    m_pixmapItem->setFlag(QGraphicsItem::ItemIsMovable);
    m_pixmapItem->setCursor(Qt::CrossCursor);
    m_pixmapItem->setZValue(0);
    scene->addItem(m_pixmapItem);
    m_pixmapItem->grabKeyboard();

    m_selectionArea = new SelectionArea(m_pixmapItem);
    m_selectionArea->setZValue(1);
    //scene->addItem(m_selectionArea);

    connect(m_pixmapItem, SIGNAL(centerItem()), this, SLOT(positionPixmapItem()));
    connect(m_pixmapItem, SIGNAL(selectionAreaChanged(QPointF,QPointF)), this, SLOT(setSelectionArea(QPointF,QPointF)));
}

ImagePanelWidget::~ImagePanelWidget()
{
    delete m_pixmapItem;
}

void ImagePanelWidget::setPixmap(const QPixmap &pix)
{
    m_pixmap = pix;
    m_pixmapItem->setPixmap(pix);
    positionPixmapItem();
}

void ImagePanelWidget::positionPixmapItem()
{
    // avoid infinite looping
    disconnect(m_pixmapItem, SIGNAL(centerItem()), this, SLOT(positionPixmapItem()));

    QRectF viewRect = m_pixmapItem->mapFromScene(mapToScene(viewport()->geometry())).boundingRect();
    QRectF itemRect = m_pixmapItem->boundingRect();

    // converges to the required value
    for (int i = 0; i < 2; ++i)
    {
        if (viewRect.width() > itemRect.width())
            m_pixmapItem->setX((sceneRect().width() - itemRect.width()) / 2.0);
        if (viewRect.height() > itemRect.height())
            m_pixmapItem->setY((sceneRect().height() - itemRect.height()) / 2.0);
    }

    m_pixmapItem->checkBoundaries();

    connect(m_pixmapItem, SIGNAL(centerItem()), this, SLOT(positionPixmapItem()));
}

void ImagePanelWidget::scaleView(qreal scaleFactor, bool notify)
{


    qreal factor = transform().scale(scaleFactor, scaleFactor).mapRect(QRectF(0, 0, 1, 1)).width();
    if (factor < 0.007 || factor > 10000)
        return;
    scale(scaleFactor, scaleFactor);

    m_scale *= scaleFactor;

    if (notify) emit zoomAt(m_scale);

    positionPixmapItem();

}

void ImagePanelWidget::resetZoom()
{
    scaleView(1.0 / m_scale);
}

void ImagePanelWidget::zoomIn()
{
    scaleView(qreal(1.1));

}

void ImagePanelWidget::zoomOut()
{
    scaleView( 1 / qreal(1.1));
}

void ImagePanelWidget::setSelectionArea(const QPointF &startPoint, const QPointF &endPoint)
{

    m_selectionArea->setPos(m_pixmapItem->mapFromScene(startPoint));
    m_selectionArea->setStartPoint(startPoint);
    m_selectionArea->setEndPoint(endPoint);
}

void ImagePanelWidget::drawBackground(QPainter *painter, const QRectF &rect)
{
    painter->setBrush(Qt::black);
    painter->drawRect(rect);
    QGraphicsView::drawBackground(painter, rect);
}


void ImagePanelWidget::mouseMoveEvent(QMouseEvent *event)
{
    QPointF p =  m_pixmapItem->mapFromScene(mapToScene(event->pos()));
    emit mouseAt(p.x(), p.y());

    QGraphicsView::mouseMoveEvent(event);
}

void ImagePanelWidget::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Plus:  zoomIn(); break;
    case Qt::Key_Minus: zoomOut(); break;
    default: QGraphicsView::keyPressEvent(event);
    }
}

void ImagePanelWidget::resizeEvent(QResizeEvent *event)
{
    setSceneRect(0, 0, rect().width(), rect().height());
    QGraphicsView::resizeEvent(event);
    positionPixmapItem();
}

void ImagePanelWidget::wheelEvent(QWheelEvent *event)
{
    if (event->delta() < 0)
        zoomOut();
    else
        zoomIn();
}

double ImagePanelWidget::getScale() const
{
    return m_scale;
}
