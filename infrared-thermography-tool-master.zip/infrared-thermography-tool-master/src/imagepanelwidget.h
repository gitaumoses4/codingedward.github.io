#ifndef IMAGEPANELWIDGET_H
#define IMAGEPANELWIDGET_H

// qt
#include <QGraphicsView>
#include <QPixmap>



class PixmapItem;
class SelectionArea;

/**
 * @brief The ImagePanelWidget class holds the image being displayed by the app
 */
class ImagePanelWidget : public QGraphicsView
{
    Q_OBJECT
public:
    /**
     * @brief getScale returns current scale of the the image displayed
     * @return the scale of the image displayed
     */
    double getScale() const;

    /**
     * @brief ImagePanelWidget the constructor
     * @param parent this widget's parent
     */
    ImagePanelWidget(QWidget *parent = 0);

    /**
     * @brief ~ImagePanelWidget the destructor
     */
    ~ImagePanelWidget();

signals:
    /**
     * @brief mouseAt notifies other widgets of the mouse's position relative to
     * the image item
     * @param x the x position of the mouse
     * @param y the y position of the mouse
     */
    void mouseAt(int x, int y);

    /**
     * @brief zoomAt notifies other widgets of the current zoom level of the image
     *
     * This may be required for choosing between between image quality and performance
     * trade offs.
     *
     * @param zoom the zoom level
     */
    void zoomAt(double zoom);

public slots:
    /**
     * @brief zoomIn zooms into the image
     */
    void zoomIn();

    /**
     * @brief zoomOut zooms out of the image
     */
    void zoomOut();

    /**
     * @brief resetZoom resets the zoom level
     */
    void resetZoom();

    /**
     * @brief setPixmap sets the image pixmap to be shown by the view
     * @param pix the pixmap item
     */
    void setPixmap(const QPixmap &pix);

    /**
     * @brief positionPixmapItem checks boundaries of the pixmap item
     * and restrains it.
     */
    void positionPixmapItem();


    void setSelectionArea(const QPointF &startPoint, const QPointF &endPoint);

protected:
    /**
     * @brief keyPressEvent handles key events for this widget
     * @param event the key press event
     */
    void keyPressEvent(QKeyEvent *event) Q_DECL_OVERRIDE;

    /**
     * @brief wheelEvent handles the mouse wheel event for this widget,
     * in this case we use it for zooming
     * @param event the wheel event
     */
    void wheelEvent(QWheelEvent *event)  Q_DECL_OVERRIDE;

    /**
     * @brief mouseMoveEvent handles the mouse move event of this widget
     * @param event the event
     */
    void mouseMoveEvent(QMouseEvent *event)  Q_DECL_OVERRIDE;

    /**
     * @brief drawBackground draws a custom background for this widget
     * @param painter the painter device for drawing the background
     * @param rect the bounding rectangle of this widget
     */
    void drawBackground(QPainter *painter, const QRectF & rect)  Q_DECL_OVERRIDE;

    void resizeEvent(QResizeEvent *event) Q_DECL_OVERRIDE;

    /**
     * @brief scaleView scales the view given a real scale factor
     * @param scaleFactor the scalefactor with which to scale the view
     * @param notify a flag to show that we should notify other widgets
     * of the scale change
     */
    void scaleView(qreal scaleFactor, bool notify = true);

private:

    /**
     * @brief m_scale current scaling factor of the view due to zooming
     */
    double m_scale;

    /**
     * @brief m_pixmap current pixmap loaded on the view
     */
    QPixmap m_pixmap;

    /**
     * @brief m_pixmapItem a graphics item that will hold the pixmap
     */
    PixmapItem  *m_pixmapItem;

    SelectionArea *m_selectionArea;
};

#endif // IMAGEPANELWIDGET_H
