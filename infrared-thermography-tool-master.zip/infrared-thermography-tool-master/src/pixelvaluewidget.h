#ifndef PIXELVALUEITEM_H
#define PIXELVALUEITEM_H

#include <QLabel>

/**
 * @brief The PixelValueWidget class displays the value of the pixel currently
 * under mouse
 */
class PixelValueWidget : public QLabel
{
    Q_OBJECT
public:
    /**
     * @brief PixelValueWidget the constructor
     * @param parent this widget's parent
     */
    PixelValueWidget(QWidget *parent = 0);

public slots:
    /**
     * @brief setPixel set the pixel value
     * @param p the pixel value
     */
    void setPixel(int p);

    /**
     * @brief setMouseAt set the mouse position
     * @param x the x value of the coordinate
     * @param y the y vlaue of the coordinate
     */
    void setMouseAt(int x, int y);

private:
    /**
     * @brief updateText updates the widgets text
     */
    void updateText();

    /**
     * @brief m_p the pixel value
     */
    int m_p;

    /**
     * @brief m_x the x position of the mouse
     */
    int m_x;

    /**
     * @brief m_y the y position of the mouse
     */
    int m_y;
};

#endif // PIXELVALUEITEM_H
