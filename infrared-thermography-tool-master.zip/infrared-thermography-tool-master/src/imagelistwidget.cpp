// mine
#include "imagelistwidget.h"

// qt
#include <QGroupBox>
#include <QStyleOption>
#include <QListWidget>
#include <QListWidgetItem>
#include <QVBoxLayout>
#include <QPushButton>
#include <QPainter>

// constants
#define LIST_WIDTH 200

ImageListWidget::ImageListWidget(QWidget *parent)
    : QGroupBox(tr("Images List") ,parent)
{
    // styling
    setMaximumWidth(LIST_WIDTH);
    setStyleSheet(" ImageListWidget { background-color: rgb(240, 240, 240); }");

    // initialize variables
    m_count = 0;
    m_imagesList = new QListWidget(this);
    m_clearBtn = new QPushButton(tr("Clear"), this);

    // lay out widgets
    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(m_imagesList);
    layout->addWidget(m_clearBtn);
    setLayout(layout);

    // make connections
    connect(m_clearBtn, SIGNAL(clicked(bool)), this, SLOT(clearImages()));
}

void ImageListWidget::clearImages()
{
    if (m_count == 0)
        return;

    // clears all images and notifies all
    // other widget of this.
    m_count = 0;
    m_imagesList->clear();
    emit clear();
}


void ImageListWidget::addImage(const QString &path)
{
    // add an image to the current lis of images
    QListWidgetItem *item = new QListWidgetItem(m_imagesList);
    item->setText(QString("Image_%1").arg(++m_count));
    item->setIcon(QIcon(QPixmap(path.toStdString().c_str())));
    m_imagesList->addItem(item);
}

void ImageListWidget::paintEvent(QPaintEvent *event)
{
    // overriden to support styling
    QStyleOption option;
    option.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &p, this);

    QGroupBox::paintEvent(event);
}
