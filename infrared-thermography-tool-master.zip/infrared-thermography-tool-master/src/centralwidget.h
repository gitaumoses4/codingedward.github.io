#ifndef CENTRALWIDGET_H
#define CENTRALWIDGET_H

// qt
#include <QWidget>
#include <QSet>

// opencv
#include <opencv2/imgproc.hpp>

// mine
class ControlsWidget;
class ImageListWidget;
class ImagePanelWidget;
class PixelValueWidget;
class VerticalScaleWidget;

// qwt
class QwtThermo;


/**
 * @brief The CentralWidget class this holds all the widgets for the
 * main window.
 */
class CentralWidget : public QWidget
{
    Q_OBJECT
public:
    /**
     * @brief CentralWidget the constructor
     * @param parent this widget's parent (@see MainWindow)
     */
    CentralWidget(QWidget *parent = 0);

public slots:
    /**
     * @brief clear this will reset every widget for a new list
     * of images to be processed
     *
     * This clears every setting of the current instance of the
     * application and prepares it for processing another list of
     * images.
     */
    void clear();

    /**
     * @brief zoomIn this will zoom into the image currently displayed
     */
    void zoomIn();

    /**
     * @brief zoomOut this will zoom out of the image currently displayed
     */
    void zoomOut();

    /**
     * @brief resetZoom resets the zoom level of the image
     */
    void resetZoom();

    /**
     * @brief saveImage saves current combined image as seen in
     * the display.
     *
     * Currently this saves the image in TIFF format with LZW lossless compression.
     * The path is specified by the user.
     *
     * @param path the path to the file where to save the image.
     */
    void saveImage(const QString &path);

    /**
     * @brief loadImage this loads an image from the disk given by a
     * path.
     *
     * This loads the image as a 16 bit TIFF image.
     *
     * If there's already an open image, it goes on to combine the images with the one
     * available being placed on top. For images with different widths, the images are
     * resized to take the largest width available.
     *
     * This also initializes the masks that are going to be used in processing this
     * image and updates the other widgets process this current image data
     *
     * @param path the path to the image file
     */
    void loadImage(const QString &path);

    /**
     * @brief updateImageRange this will change the range of image normalization.
     *
     * This changes the range of the image normalization algorithm to to correspond
     * to user input. It also updates the other widgets and the image displayed to
     * correspond to this value.
     *
     * The @param released is a flag for indicating that we should update other
     * widgets to correspond to this values.
     *
     * This happens when the user is dragging a slider and expects real time response
     * by the app. To provide the real time experience, we need to cut some operations
     * and perform them only when the slider is released.
     *
     * @param low lower value for normalizing the image
     * @param high upper value for normalizing the image
     * @param released the slider released flag.
     */
    void updateImageRange(int low, int high, bool released);

    /**
     * @brief updateColormap updates the colormap currently used on the display image
     * @param colormap the colormap value, -1 indicates no colormap
     */
    void updateColormap(int colormap);

    /**
     * @brief updateZoomLevel updates the zoom level for the current display image
     *
     * When the image is zoomed into, we need to resize the displayed image to enhance
     * the image and avoid pixelation. Also, when zoomed out of, we need to resize it
     * to improve performance.
     *
     * @param zoom current image zoom level.
     */
    void updateZoomLevel(double zoom);

    /**
     * @brief resetNormalize resets the image normalization range by calling
     * a normalization range detection algorithm.
     */
    void resetNormalize();

    /**
     * @brief setMouseAt alerts other widgets of the current position of the mouse
     * relative to the image displayed.
     *
     * This required by other widgets that may need to know the pixel value at current
     * mouse point.
     *
     * @param x the x coordinate of the mouse relative to the mouse.
     * @param y the y coordinate of the mouse relative to the mouse.
     */
    void setMouseAt(int x, int y);

protected:
    /**
     * @brief paintEvent the paint event of this widget overriden to allow
     * stylesheets.
     */
    void paintEvent(QPaintEvent *);

private slots:
    /**
     * @brief processDisplayImage this will process the display image based on
     * current settings e.g. normalization range and current colormap.
     */
    void processDisplayImage();

    /**
     * @brief setNormalizeInterval this has an algorithm that estimates the best
     * range for normalizing the image.
     *
     * This works by finding the smallest non zero(black) element on the real image
     * and the highest non 65535(white) value.
     *
     */
    void setNormalizeInterval();

private:
    /**
     * @brief m_imageListWidget the images list widget
     */
    ImageListWidget     *m_imageListWidget;

    /**
     * @brief m_controlsWidget the controls widget
     */
    ControlsWidget      *m_controlsWidget;

    /**
     * @brief m_imagePanelWidget the display image panel
     */
    ImagePanelWidget    *m_imagePanelWidget;

    /**
     * @brief m_pixelValueWidget the pixel value widget
     */
    PixelValueWidget    *m_pixelValueWidget;

    /**
     * @brief m_scaleWidget the vertical scale widget
     */
    VerticalScaleWidget *m_scaleWidget;

    /**
     * @brief m_imagePaths paths to all images currently opened
     */
    QSet<QString> m_imagePaths;

    /**
     * @brief m_realMat the real image matrix, this is not modified
     * for display purposes.
     */
    cv::Mat m_realMat;

    /**
     * @brief m_dispMat the display image matrix, modified by colormaps
     * and zoom values and normalizing in the application.
     */
    cv::Mat m_dispMat;

    /**
     * @brief m_normMask a mask used for normalizing the display matrix.
     */
    cv::Mat m_normMask;

    /**
     * @brief m_upperMask a mask used to set all values higher than current image
     * normalization range to white for enhancement.
     */
    cv::Mat m_upperMask;

    /**
     * @brief m_normalizeMin lower image normalization value
     */
    int m_normalizeMin;

    /**
     * @brief m_normalizeMax upper image normalization value
     */
    int m_normalizeMax;

    /**
     * @brief m_colormap current colormap, -1 if no colormap has been set.
     */
    int m_colormap;

    /**
     * @brief m_zoomLevel current zoom value used for enhancing display image
     * when zoomed into, and enhancing performance when zoom out of.
     */
    double m_zoomLevel;
};

#endif // CENTRALWIDGET_H
