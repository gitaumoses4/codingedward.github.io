// mine
#include "centralwidget.h"
#include "mainwindow.h"

// qt
#include <QFileDialog>
#include <QMenu>
#include <QMenuBar>
#include <QToolBar>
#include <QSettings>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    // styling
    setAttribute(Qt::WA_DeleteOnClose);
    setStyleSheet("CentralWidget { background-color: rgb(150, 150, 150); }");

    // set the central widget
    m_centralWidget = new CentralWidget(this);
    setCentralWidget(m_centralWidget);

    // set up the actions
    m_openAct = new QAction(QIcon(":/resources/open.png"), tr("&Open"), this);
    m_openAct->setShortcut(QKeySequence::Open);
    m_openAct->setStatusTip(tr("Open an image"));
    connect(m_openAct, SIGNAL(triggered(bool)), this, SLOT(loadImage()));

    m_saveAct = new QAction(QIcon(":/resources/save.png"), tr("&Save"), this);
    m_saveAct->setShortcut(QKeySequence::Save);
    m_saveAct->setStatusTip(tr("Save image"));
    connect(m_saveAct, SIGNAL(triggered(bool)), this, SLOT(saveImage()));

    m_zoomInAct = new QAction(QIcon(":/resources/zoomin.png"), tr("Zoom &In"), this);
    m_zoomInAct->setShortcut(QKeySequence::ZoomIn);
    m_zoomInAct->setStatusTip(tr("Zoom in"));
    connect(m_zoomInAct, SIGNAL(triggered(bool)), m_centralWidget, SLOT(zoomIn()));

    m_zoomOutAct = new QAction(QIcon(":/resources/zoomout.png"), tr("Zoom Ou&t"), this);
    m_zoomOutAct->setShortcut(QKeySequence::ZoomOut);
    m_zoomOutAct->setStatusTip(tr("Zoom out"));
    connect(m_zoomOutAct, SIGNAL(triggered(bool)), m_centralWidget, SLOT(zoomOut()));

    m_resetZoomAct = new QAction(QIcon(":/resources/zoomfit.png"), tr("&Reset Zoom"), this);
    m_resetZoomAct->setStatusTip(tr("Reset zooming"));
    connect(m_resetZoomAct, SIGNAL(triggered(bool)), m_centralWidget, SLOT(resetZoom()));

    m_clearAct = new QAction(QIcon(":/resources/clear.png"), tr("&Clear"), this);
    m_clearAct->setStatusTip(tr("Clear all images"));
    connect(m_clearAct, SIGNAL(triggered(bool)), m_centralWidget, SLOT(clear()));

    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(m_openAct);
    fileMenu->addAction(m_saveAct);

    m_toolbar = new QToolBar(this);
    m_toolbar->addAction(m_openAct);
    m_toolbar->addAction(m_saveAct);
    m_toolbar->addAction(m_clearAct);
    m_toolbar->addSeparator();
    m_toolbar->addAction(m_zoomInAct);
    m_toolbar->addAction(m_zoomOutAct);
    m_toolbar->addAction(m_resetZoomAct);
    m_toolbar->setStyleSheet("QToolBar { background-color: rgb(190, 190, 190); }");
    addToolBar(Qt::TopToolBarArea, m_toolbar);

    setWindowIcon(QIcon(":/resources/icon.png"));
}

void MainWindow::loadImage()
{
    QSettings settings("visrx", "IRLINE2");
    QString searchPath = settings.value("searchPath", ".").toString();
    QString path = QFileDialog::getOpenFileName(this,
                                                tr("Open Image"), searchPath,
                                                tr("Image Files (*.tiff *.tif)"));
    if (path.isEmpty())
        return;
    m_centralWidget->loadImage(path);
    settings.setValue("searchPath", QDir(path).absolutePath());
}

void MainWindow::saveImage()
{
    QSettings settings("visrx", "IRLINE2");
    QString savePath = settings.value("savePath", ".").toString();
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    tr("Save Image"), savePath,
                                                    tr("TIFF Images (*.tif)"));
    if (fileName.isEmpty())
        return;

    m_centralWidget->saveImage(fileName);
    settings.setValue("savePath", QDir(fileName).absolutePath());
}
