// mine
#include "centralwidget.h"
#include "imagelistwidget.h"
#include "controlswidget.h"
#include "imagepanelwidget.h"
#include "pixelvaluewidget.h"
#include "verticalscalewidget.h"

// qwt
#include <qwt_thermo.h>
#include <qwt_color_map.h>
#include <qwt_scale_engine.h>

// qt
#include <QGridLayout>
#include <QLabel>
#include <QMessageBox>
#include <QVBoxLayout>
#include <QSlider>
#include <QStyleOption>
#include <QSpacerItem>

// opencv
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

// stl
#include <limits>

// constants
#define MAX_VAL 65535
#define MAX_ZOOM_FIX 7          // max zoom value
#define MIN_ZOOM_FIX 0.000001   // least zoom value


CentralWidget::CentralWidget(QWidget *parent)
    : QWidget(parent)
{

    // initialize all variables
    m_colormap = -1;
    m_zoomLevel = 1;
    m_scaleWidget = new VerticalScaleWidget(this);
    m_controlsWidget = new ControlsWidget(this);
    m_imageListWidget = new ImageListWidget(this);
    m_pixelValueWidget = new PixelValueWidget(this);
    m_imagePanelWidget = new ImagePanelWidget(this);

    // lay out the widgets.
    QGridLayout *layout = new QGridLayout(this);
    QLabel *label = new QLabel(this); //------- for padding top
    layout->addWidget(label, 0, 0, 1, 50);

    //  widget, row, column, rspan, cspan
    layout->addWidget(m_imageListWidget,  1,  0,  8,  3);
    layout->addWidget(m_imagePanelWidget, 1,  3,  19, 39);
    layout->addWidget(m_scaleWidget,      1,  42, 19, 4);
    layout->addWidget(m_controlsWidget,   1,  46, 4,  4);
    layout->addWidget(m_pixelValueWidget, 20,  1,  3, 40);


    // make all connections.
    connect(m_controlsWidget, SIGNAL(resetNormalizeImage()), this, SLOT(resetNormalize()));
    connect(m_controlsWidget, SIGNAL(resetZoomLevel()), this, SLOT(resetZoom()));
    connect(m_controlsWidget, SIGNAL(colormapChanged(int)), this, SLOT(updateColormap(int)));
    connect(m_controlsWidget, SIGNAL(scaleChanged(int,int,bool)), this, SLOT(updateImageRange(int, int, bool)));
    connect(m_controlsWidget, SIGNAL(scaleChanged(int,int,bool)), m_scaleWidget, SLOT(changeScale(int,int)));
    connect(m_scaleWidget, SIGNAL(scaleChanged(int,int,bool)), m_controlsWidget, SLOT(changeScale(int,int)));
    connect(m_scaleWidget, SIGNAL(scaleChanged(int, int, bool)), this, SLOT(updateImageRange(int, int, bool)));
    connect(m_imagePanelWidget, SIGNAL(zoomAt(double)), this, SLOT(updateZoomLevel(double)));
    connect(m_imagePanelWidget, SIGNAL(mouseAt(int, int)), this, SLOT(setMouseAt(int, int)));
    connect(m_imageListWidget, SIGNAL(clear()), this, SLOT(clear()));
}

void CentralWidget::saveImage(const QString &path)
{
    // can't save empty image
    if (m_realMat.empty())
    {
        QMessageBox::information(this, tr("Empty Image"), tr("Could not save empty image"));

        return;
    }

    // save the image
    try
    {
        cv::imwrite(path.toStdString().c_str(), m_realMat);
    }
    catch (cv::Exception &e)
    {
        QMessageBox::critical(this,
                              tr("Error"),
                              tr("Unable to write image %1. Error: %2").arg(path).arg(e.what()));
        return;
    }

    QMessageBox::information(this,
                             tr("Saved"),
                             tr("Image successfully saved"));
}


void CentralWidget::loadImage(const QString &path)
{
    // read the image
    cv::Mat tmp = cv::imread(path.toStdString().c_str(),
                             cv::IMREAD_UNCHANGED | cv::IMREAD_ANYDEPTH);

    // read failed
    if (! tmp.data)
    {
        QMessageBox::critical(this,
                              tr("Error"),
                              tr("Could not read the image given."),
                              QMessageBox::Ok);
        return;
    }


    // if current image matrix is not empty, we want to
    // append the new image below the current image
    if (! m_realMat.empty())
    {
        // resize the small image to larger one
        if (m_realMat.cols > tmp.cols)
            cv::resize(tmp, tmp, cv::Size(m_realMat.cols, tmp.rows), 0, 0, cv::INTER_CUBIC);
        else if (m_realMat.cols < tmp.cols)
            cv::resize(m_realMat, m_realMat, cv::Size(tmp.cols, m_realMat.rows), 0, 0, cv::INTER_CUBIC);

        // now combine the two images...
        cv::Mat newMat(m_realMat.rows + tmp.rows, m_realMat.cols, m_realMat.type());

        for (int i = 0; i < m_realMat.rows; ++i)
            for (int j = 0; j < m_realMat.cols; ++j)
                newMat.at<ushort>(i, j) = m_realMat.at<ushort>(i, j);

        for (int i = 0; i < tmp.rows; ++i)
            for (int j = 0; j < tmp.cols; ++j)
                newMat.at<ushort>(i + m_realMat.rows, j) = tmp.at<ushort>(i, j);

        newMat.copyTo(m_realMat);
    }
    else // when this is the first image
    {
        tmp.copyTo(m_realMat);
    }

    // initialize masks
    m_normMask = cv::Mat(m_realMat.size(), CV_8U);
    m_upperMask = cv::Mat(m_realMat.size(), CV_8U);

    // update display
    setNormalizeInterval();
    processDisplayImage();

    // update other widgets
    m_imagePaths.insert(path);
    m_imageListWidget->addImage(path);
    m_controlsWidget->updateHistogram(m_dispMat);
    m_imagePanelWidget->resetZoom();

}

void CentralWidget::processDisplayImage()
{

    if (m_realMat.empty()) return;

    int low = m_normalizeMin;
    int high = m_normalizeMax;

    // find the upper mask that should be set to white.
    cv::inRange(m_realMat, cv::Scalar(high, high, high), cv::Scalar(MAX_VAL, MAX_VAL, MAX_VAL), m_upperMask);

    // find the mask for values in normalization range.
    cv::inRange(m_realMat, cv::Scalar(low, low, low),  cv::Scalar(high, high, high), m_normMask);

    // reset display matrix and set higher values to white
    m_dispMat = cv::Mat::zeros(m_realMat.size(), m_realMat.type());
    m_dispMat.setTo(cv::Scalar(MAX_VAL, MAX_VAL, MAX_VAL), m_upperMask);

    // normalize display matrix
    cv::normalize(m_realMat, m_dispMat, 0, MAX_VAL, cv::NORM_MINMAX, -1, m_normMask);

    // convert it to 8 bit for display
    m_dispMat.convertTo(m_dispMat, CV_8U, 1.0/255.0);

    // enhance in case of zoom
    double zoom = qMax(qMin<double>(m_zoomLevel, MAX_ZOOM_FIX), MIN_ZOOM_FIX);
    cv::resize(m_dispMat, m_dispMat, cv::Size(m_dispMat.cols * zoom, m_dispMat.rows * zoom), 0, 0, cv::INTER_CUBIC);

    // now display the image.
    QImage image;
    if (m_colormap < 0)
    {
        // no colormap to apply, just display image
        cv::cvtColor(m_dispMat, m_dispMat, cv::COLOR_GRAY2RGB);
        image = QImage((uchar*)m_dispMat.data,
                       m_dispMat.cols, m_dispMat.rows,
                       m_dispMat.step, QImage::Format_RGB888);
        m_imagePanelWidget->setPixmap(QPixmap::fromImage(image));
    }
    else
    {
        // apply colormap and display
        cv::Mat imgColormapMat;
        cv::applyColorMap(m_dispMat, imgColormapMat, m_colormap);

        cv::cvtColor(imgColormapMat, imgColormapMat, cv::COLOR_BGR2RGB);
        image = QImage((uchar*)imgColormapMat.data,
                       imgColormapMat.cols, imgColormapMat.rows,
                       imgColormapMat.step, QImage::Format_RGB888);
        m_imagePanelWidget->setPixmap(QPixmap::fromImage(image));
    }
}

void CentralWidget::updateImageRange(int low, int high, bool released)
{
    if (m_realMat.empty()) return;

    // change only if the new values are different
    if (m_normalizeMin != low || m_normalizeMax != high)
    {
        m_normalizeMin = low;
        m_normalizeMax = high;
        processDisplayImage();
    }

    // slider released, we need to update the histogram
    if (released) m_controlsWidget->updateHistogram(m_dispMat);
}


void CentralWidget::setMouseAt(int x, int y)
{
    // update current mouse position
    m_pixelValueWidget->setMouseAt(x, y);

    if (! m_dispMat.data) return;

    // check that the point is in the display matrix
    int exclude = 3; // avoid index out of bounds
    if (x > m_dispMat.cols - exclude || x < exclude
            || y < exclude || y > m_dispMat.rows - exclude)
        return;

    // square pixel valus since display matrix is in 8 bit
    m_pixelValueWidget->setPixel(m_dispMat.at<uchar>(y, x)
                                 * m_dispMat.at<uchar>(y, x));
}

void CentralWidget::updateColormap(int colormap)
{
    // update current colormap
    m_colormap = colormap;
    m_scaleWidget->changeColormap(colormap);

    // process image if not empty
    if (m_realMat.empty()) return;

    processDisplayImage();
}

void CentralWidget::updateZoomLevel(double zoom)
{
    if (m_realMat.empty() || m_zoomLevel == zoom) return;

    // set current zoom level and update display
    m_zoomLevel = zoom;
    processDisplayImage();
}



void CentralWidget::setNormalizeInterval()
{
    // find normalize range, the range is given by the least
    // non zero value and the highest non MAX_VAL value.
    m_normalizeMin = std::numeric_limits<ushort>::max();
    m_normalizeMax = std::numeric_limits<ushort>::min();

    for (int i = 0; i < m_realMat.rows; ++i)
        for (int j = 0; j < m_realMat.cols; ++j)
        {
            ushort current = m_realMat.at<ushort>(i, j);
            if (current != 0 && current < m_normalizeMin)
                m_normalizeMin = current;
            if (current != MAX_VAL && current > m_normalizeMax)
                m_normalizeMax = current;
        }

    // update scale
    m_scaleWidget->changeScale(m_normalizeMin, m_normalizeMax);
}

void CentralWidget::clear()
{
    if (m_realMat.empty()) return;

    // clear matrices
    m_realMat.release();
    m_dispMat.release();

    // reset other widgets
    m_controlsWidget->clear();
    m_imagePanelWidget->resetZoom();
    m_imagePanelWidget->setPixmap(QPixmap());
    m_imageListWidget->clearImages();
}

void CentralWidget::zoomIn()
{
    if (m_realMat.empty()) return;

    m_imagePanelWidget->zoomIn();
}

void CentralWidget::zoomOut()
{
    if (m_realMat.empty()) return;

    m_imagePanelWidget->zoomOut();
}

void CentralWidget::resetZoom()
{
    if (m_realMat.empty()) return;

    m_imagePanelWidget->resetZoom();
}

void CentralWidget::resetNormalize()
{
    if (m_realMat.empty()) return;

    // resets the range for normalization with
    // values estimated by setNormalizeInterval()
    setNormalizeInterval();
    processDisplayImage();

    // update histogram
    m_controlsWidget->updateHistogram(m_dispMat);
}

void CentralWidget::paintEvent(QPaintEvent *)
{
    // enables stylesheet
    QStyleOption option;
    option.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &p, this);
}
