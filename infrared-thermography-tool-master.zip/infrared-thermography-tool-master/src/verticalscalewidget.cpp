// mine
#include "verticalscalewidget.h"
#include "verticalscale.h"
#include "verticalslider.h"

// qt
#include <QHBoxLayout>
#include <QPainter>
#include <QStyleOption>


VerticalScaleWidget::VerticalScaleWidget(QWidget *parent)
    : QWidget(parent)
{
    // style up
    setStyleSheet(" VerticalScaleWidget { background-color: rgba(250, 250, 250, 80); }");

    // initialize widgets
    m_scale = new VerticalScale(this);
    m_slider = new VerticalSlider(this);

    // setup the layout
    QHBoxLayout *layout = new QHBoxLayout(this);
    layout->addWidget(m_scale);
    layout->addWidget(m_slider);

    // make connections
    connect(m_slider, SIGNAL(sliderReleased()), SLOT(syncScaleReleased()));
    connect(m_slider, SIGNAL(spanChanged(int,int)), SLOT(syncScaleDragged()));
}

void VerticalScaleWidget::changeColormap(int colormap)
{
    // set scale's liquid colormap
    m_scale->setScaleColormap(colormap);
}

void VerticalScaleWidget::syncScaleDragged()
{
    // signal change of the scale, false as the slider has not been released
    emit scaleChanged(m_slider->lowerValue(), m_slider->upperValue(), false);
}

void VerticalScaleWidget::changeScale(int low, int high)
{
    if (low == m_slider->lowerValue() && high == m_slider->upperValue())
        return;

    // avoid infinite looping
    disconnect(m_slider, SIGNAL(spanChanged(int,int)), this, SLOT(syncScaleDragged()));

    m_slider->setRange(low, high);
    m_slider->setSpan(low, high);
    syncScaleReleased();

    connect(m_slider, SIGNAL(spanChanged(int,int)), this, SLOT(syncScaleDragged()));
}

void VerticalScaleWidget::syncScaleReleased()
{
    // this calculates if the scales should change values and also
    // updates them with this values and for the slider,
    // it updates it with some margin
    int scaleMax = m_scale->upperBound();
    int scaleMin = m_scale->lowerBound();
    int sliderMax = m_slider->upperValue();
    int sliderMin = m_slider->lowerValue();
    int margin = 0.1 * (scaleMax - scaleMin);

    m_scale->customSetRange((sliderMin - margin) < 0 ? 0 : sliderMin - margin,
                            (sliderMax + margin) > 65535 ? 65535 : sliderMax + margin);

    m_slider->setRange(m_scale->lowerBound(), m_scale->upperBound());

    // signal change of the scale, true as the slider has  been released
    emit scaleChanged(m_slider->lowerValue(), m_slider->upperValue(), true);
}

void VerticalScaleWidget::paintEvent(QPaintEvent *)
{
    // support styling
    QStyleOption option;
    option.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &option, &p, this);
}
