#include "selectionarea.h"

#include <QBrush>
#include <QPainter>
#include <QPen>
#include <QGraphicsScene>


SelectionArea::SelectionArea(QGraphicsItem *parent)
    : QGraphicsItem(parent)
{
}


void SelectionArea::setStartPoint(QPointF startPoint)
{
    m_startPoint =  mapFromScene(startPoint);
}

void SelectionArea::setEndPoint(QPointF endPoint)
{
    if (! parentItem()) return;

    QRectF parentRect = parentItem()->mapToScene(parentItem()->boundingRect()).boundingRect();

    if (parentRect.left() > endPoint.x())
        endPoint.setX(parentRect.left());
    else if (parentRect.right() < endPoint.x())
       endPoint.setX(parentRect.right());


    if (parentRect.top() > endPoint.y())
        endPoint.setY(parentRect.top());
    else if (parentRect.bottom() < endPoint.y())
        endPoint.setY(parentRect.bottom());

    m_endPoint = mapFromScene(endPoint);
    scene()->update(scene()->sceneRect());
}

QRectF SelectionArea::boundingRect() const
{
    return QRectF(m_startPoint, m_endPoint);
}


void SelectionArea::paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *)
{
    QRectF rect = boundingRect();
    if ( qAbs(rect.height()) > 0.001 && qAbs(rect.width()) > 0.001)
    {
        painter->setPen(QPen(Qt::red, 1, Qt::SolidLine));
        painter->drawRect(boundingRect());
    }
}
