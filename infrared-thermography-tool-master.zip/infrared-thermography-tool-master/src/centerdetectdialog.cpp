#include "centerdetectdialog.h"

CenterDetectDialog::CenterDetectDialog(QWidget *parent)
    : QDialog(parent)
{

}
