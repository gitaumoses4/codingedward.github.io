#ifndef VERTICALSLIDER_H
#define VERTICALSLIDER_H

#include "qxtspanslider.h"

class VerticalSlider : public QxtSpanSlider
{
    Q_OBJECT
public:
    VerticalSlider(QWidget *parent = 0);
};

#endif // VERTICALSLIDER_H
