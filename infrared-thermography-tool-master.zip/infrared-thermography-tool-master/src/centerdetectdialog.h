#ifndef CENTERDETECTDIALOG_H
#define CENTERDETECTDIALOG_H

#include <QDialog>

class QLabel;
class QSpinBox;

class CenterDetectDialog : public QDialog
{
    Q_OBJECT
public:
    CenterDetectDialog(QWidget *parent = 0);


private:
    QLabel *m_ROILbl;
    QLabel *m_clusteredLbl;
};

#endif // CENTERDETECTDIALOG_H
