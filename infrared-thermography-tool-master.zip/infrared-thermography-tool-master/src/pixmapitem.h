#ifndef PIXMAPITEM_H
#define PIXMAPITEM_H


// qt
#include <QGraphicsPixmapItem>
#include <QObject>


/**
 * @brief The PixmapItem class this will hold the image displayed
 * by the application
 */
class PixmapItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    /**
     * @brief PixmapItem the constructor
     * @param parent this widget's parent
     */
    PixmapItem(QGraphicsItem *parent = 0);

    /**
     * @brief checkBoundaries restrains the item in the view
     */
    void checkBoundaries();

signals:
    /**
     * @brief centerItem notifies that this item needs to be centered
     */
    void centerItem();

    void selectionAreaChanged(QPointF startPoint, QPointF endPoint);

protected:

    /**
     * @brief itemChange overriden to support checking the
     * @param change
     * @param value
     * @return
     */
    QVariant itemChange(GraphicsItemChange change, const QVariant &value) Q_DECL_OVERRIDE;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) Q_DECL_OVERRIDE;
    void mousePressEvent(QGraphicsSceneMouseEvent *event) Q_DECL_OVERRIDE;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) Q_DECL_OVERRIDE;
    void keyReleaseEvent(QKeyEvent *event) Q_DECL_OVERRIDE;

private:
    QPointF m_selectionStart;
    QSizeF m_selectionSize;
};

#endif // PIXMAPITEM_H
