#ifndef IMAGELIST_H
#define IMAGELIST_H

// qt
#include <QGroupBox>

class QPushButton;
class QListWidget;

/**
 * @brief The ImageListWidget class holds a list of images already opened
 */
class ImageListWidget  : public QGroupBox
{
    Q_OBJECT
public:
    /**
     * @brief ImageListWidget the constructor
     * @param parent this widget's parent
     */
    ImageListWidget(QWidget *parent = 0);

signals:
    /**
     * @brief clear notifies other widgets of image list being cleared
     */
    void clear();

public slots:
    /**
     * @brief addImage adds an image to current list of images
     * @param path the path to image file to add
     */
    void addImage(const QString &path);

    /**
     * @brief clearImages this will clear current list of images and notify
     * other widgets of the clearing
     */
    void clearImages();

protected:
    /**
     * @brief paintEvent this widget's paint event overriden to
     * support styling
     * @param event the event
     */
    void paintEvent(QPaintEvent *event);

private:
    /**
     * @brief m_count count of the open images
     */
    int         m_count;

    /**
     * @brief m_imagesList this widget holds the list of images
     */
    QListWidget *m_imagesList;

    /**
     * @brief m_clearBtn for clearing all the images
     */
    QPushButton *m_clearBtn;
};

#endif // IMAGELIST_H
