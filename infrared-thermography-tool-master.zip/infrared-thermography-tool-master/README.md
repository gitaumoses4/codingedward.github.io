# :boom: Infrared Thermography Tool :boom:

## About
This project is a tool for applying different colormaps, normalizing and combining images to enhance their 
analysis in [infrared thermography](https://en.wikipedia.org/wiki/Thermography).
The images loaded by the application are 16 bit TIFF images to ensure high quality.

![cool app](https://github.com/codingedward/infrared-thermography-tool/blob/master/image.png)


## Building
This project was built using Qt 5.5, MinGW492_32, OpenCV 3.0, Qwt 6.1.3 on Windows 8.1
In order to compile it you will need to setup the path to two libraries in the  
project (.pro) file:

1. Qwt 6.1.3 - both the sources and the libraries
2. OpenCV 3.0 - both the sources and the libraries 
